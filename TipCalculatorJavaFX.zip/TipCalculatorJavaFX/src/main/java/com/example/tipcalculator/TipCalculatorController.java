package com.example.tipcalculator;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.Locale;

public class TipCalculatorController {
    @FXML private TextField billAmountField;
    @FXML private TextField tipPercentageField;
    @FXML private Label tipAmountLabel;
    @FXML private Label errorMessageLabel;

    @FXML
    private void calculateTip() {
        errorMessageLabel.setText("");
        tipAmountLabel.setText("");

        try {
            String billText = billAmountField.getText().trim();
            String percentageText = tipPercentageField.getText().trim();

            if (billText.isEmpty() || percentageText.isEmpty()) {
                errorMessageLabel.setText("Please enter both values.");
                return;
            }

            double billAmount = Double.parseDouble(billText);
            double tipPercentage = Double.parseDouble(percentageText);

            if (!Double.isFinite(billAmount) || !Double.isFinite(tipPercentage)) {
                errorMessageLabel.setText("Error: Please enter valid numbers.");
                return;
            }
            if (billAmount < 0 || tipPercentage < 0) {
                errorMessageLabel.setText("Bill amount and tip percentage cannot be negative.");
                return;
            }

            double tipAmount = billAmount * tipPercentage / 100.0;
            tipAmountLabel.setText(String.format(Locale.US, "Tip Amount: $%.2f", tipAmount));
        } catch (NumberFormatException ex) {
            errorMessageLabel.setText("Error: Invalid input. Please enter numbers.");
        }
    }

    @FXML
    private void reset() {
        billAmountField.clear();
        tipPercentageField.clear();
        tipAmountLabel.setText("");
        errorMessageLabel.setText("");
    }
}
