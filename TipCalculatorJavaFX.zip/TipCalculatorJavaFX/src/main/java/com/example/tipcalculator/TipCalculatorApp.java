package com.example.tipcalculator;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class TipCalculatorApp extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                TipCalculatorApp.class.getResource("/com/example/tipcalculator/tip_calculator.fxml"));
        Scene scene = new Scene(loader.load(), 420, 340);
        stage.setTitle("Tip Calculator");
        stage.setScene(scene);
        stage.setMinWidth(380);
        stage.setMinHeight(320);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
