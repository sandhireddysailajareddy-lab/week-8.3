# Tip Calculator (JavaFX + FXML)

## Requirements
- JDK 17 or newer
- Maven
- JavaFX dependencies are downloaded by Maven

## Run
From the project folder, run:

```bash
mvn clean javafx:run
```

## Example
- Bill Amount: `50.00`
- Tip Percentage: `15`
- Result: `Tip Amount: $7.50`

Invalid non-numeric input displays an error message. Reset clears both fields and all labels.

## Files
- `TipCalculatorApp.java` — launches the JavaFX window and loads FXML.
- `TipCalculatorController.java` — validates input, calculates the tip, and resets the form.
- `tip_calculator.fxml` — defines the UI and connects the controller.
